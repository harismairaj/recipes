Changelog
=========

2.1.2  (December 11, 2019)
--------------------------
- Enh: Improved HumHub 1.4+ compatibility


2.1.1  (December 10, 2018)
--------------------------
- Enh: Improved theme caching for HumHub 1.3.7+


2.1.0  (July 4, 2018)
---------------------
- Enh: Allow to specify update channel


2.0.8  (July 2, 2018)
---------------------
- Fix: PHP 7.2 compatibility issues
