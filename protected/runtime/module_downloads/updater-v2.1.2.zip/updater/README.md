## Description

Automatic HumHub Updater.

__Module website:__ <https://github.com/humhub/humhub-modules-updater>    
__Author:__ luke    
__Author website:__ [humhub.org](http://humhub.org)    

## Changelog

<https://github.com/humhub/humhub-modules-updater/commits/master>

## Bugtracker

<https://github.com/humhub/humhub-modules-updater/issues>

## Usage

Web: You can find the updater under Administration -> Manage -> Update HumHub

- or - 

Console: yiic updater
