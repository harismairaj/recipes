<?php

return [
    'Update download failed! (%error%)' => '',
];
