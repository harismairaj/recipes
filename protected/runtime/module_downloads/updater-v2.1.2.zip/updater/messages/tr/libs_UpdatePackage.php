<?php
return array (
  'Update download failed! (%error%)' => 'Güncelleme indirme başarısız! (%error%)',
);
