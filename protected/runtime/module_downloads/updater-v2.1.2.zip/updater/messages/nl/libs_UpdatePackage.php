<?php
return array (
  'Update download failed! (%error%)' => 'Nieuwe versie ophalen is mislukt! (%error%)',
);
