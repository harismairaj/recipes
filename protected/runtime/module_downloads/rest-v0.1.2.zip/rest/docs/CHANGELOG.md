Changelog
=========

0.1.2  (January 31, 2020)
-------------------------
- Enh: Added User group endpoint



0.1.1  (January 17, 2020)
-------------------------
- Initial release in marketplace
- Chg: Removed 'members' attribute from 'Space' output object
- Enh: Added Space Membership Endpoint


0.1.0  (20 December, 2019)
---------------------------
- Initial release in marketplace
- Enh: Various new endpoints and features


0.0.1  (Unrelased)
------------------------
Initial release
